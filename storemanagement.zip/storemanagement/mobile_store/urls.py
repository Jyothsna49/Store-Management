from django.contrib import admin
from django.urls import path
from .views import *
from django.conf.urls import url

urlpatterns=[
    path('admin/',admin.site.urls),
    
    path('Bill',Bill,name="Bill"),
    path('orders',orders,name='orders'),
    path('orders/edit_item/<pk>', edit_order, name="edit_order"),
    path('orders/delete_order/<pk>', delete_order, name="delete_order"),
    path('display_order', display_order, name="display_order"),
    path('view_order/<pk>', view_order, name="view_order"),

    path('', display_mobiles, name='display_mobiles'),
    path('mobiles', display_mobiles, name="display_mobiles"),
    path('earphones', display_earphones, name="display_earphones"),
    path('screenguards', display_screenguards, name="display_screenguards"),
    path('casescovers', display_cases_covers, name="display_cases_covers"),

    path('mobiles/add_mobile', add_mobile, name="add_mobile"),
    path('add_earphone', add_earphone, name="add_earphone"),
    path('add_screenguard', add_screenguard, name="add_screenguard"),
    path('add_cases_covers', add_cases_covers, name="add_cases_covers"),

    path('mobiles/edit_item/<pk>', edit_mobile, name="edit_mobile"),
    path('earphones/edit_item/<pk>', edit_earphone, name="edit_earphone"),
    path('screenguards/edit_item/<pk>', edit_screenguard, name="edit_screenguard"),
    path('casescovers/edit_item/<pk>', edit_cases_covers, name="edit_cases_covers"),
    path("search",search,name="search"),
    path(r'^three$',three,name="three"),

    path('mobiles/delete/<pk>', delete_mobile, name="delete_mobile"),
    path('earphones/delete/<pk>', delete_earphone, name="delete_earphone"),
    path('screenguards/delete/<pk>', delete_screenguard, name="delete_screenguard"),
    path('casescovers/delete/<pk>', delete_cases_covers, name="delete_cases_covers")
]