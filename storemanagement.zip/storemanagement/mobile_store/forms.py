from django import forms
from .models import *

class MobilePhoneForm(forms.ModelForm):
    class Meta:
        model = MobilePhone
        fields = ('brand', 'model', 'price', 'in_stock','FreeGift')

class EarPhoneForm(forms.ModelForm):
    class Meta:
        model = EarPhone
        fields = ('brand', 'model', 'price', 'in_stock','FreeGift')

class ScreenguardForm(forms.ModelForm):
    class Meta:
        model = Screenguard
        fields = ('brand', 'model', 'price', 'in_stock')

class Cases_and_CoverForm(forms.ModelForm):
    class Meta:
        model = Cases_and_Cover
        fields = ('brand', 'model', 'price', 'in_stock')

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ('customer_name','customer_number', 'type_of_product', 'brand', 'model', 'price', 'FreeGift','discount_amount','discount_percent','final_price')