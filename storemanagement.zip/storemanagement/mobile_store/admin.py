from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(MobilePhone)
admin.site.register(EarPhone)
admin.site.register(Cases_and_Cover)
admin.site.register(Screenguard)
admin.site.register(Order)
