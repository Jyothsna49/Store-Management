from django.db import models

# Create your models here.
class Product(models.Model):
    brand=models.CharField(max_length=20)
    model=models.CharField(max_length=40)
    price=models.DecimalField( max_digits = 9,decimal_places = 2)
    in_stock=models.IntegerField()

    class Meta:
        abstract = True

    def __str__(self):
        return '{0} {1}'.format(self.brand, self.model)
    
class MobilePhone(Product):
    FreeGift=models.CharField(max_length=25)
class EarPhone(Product):
    FreeGift=models.CharField(max_length=25)
class Cases_and_Cover(Product):
    pass
class Screenguard(Product):
    pass

class Order(models.Model):
    customer_name=models.CharField(max_length=30)
    customer_number=models.CharField(max_length=20)
    date=models.DateTimeField(auto_now_add=True,auto_now=False)
    type_of_product=models.CharField(max_length=20)
    brand=models.CharField(max_length=20)
    model=models.CharField(max_length=40)
    price=models.DecimalField( default=00.0, max_digits = 9,decimal_places = 2)
    FreeGift=models.CharField(max_length=25,default='-')
    discount_percent=models.IntegerField(default='0', blank=True, null=True)
    discount_amount=models.DecimalField(default=00.0, max_digits = 9,decimal_places = 2)
    final_price=models.DecimalField(default=00.0, max_digits = 9,decimal_places = 2)