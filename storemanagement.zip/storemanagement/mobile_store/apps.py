from django.apps import AppConfig


class MobileStoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mobile_store'
