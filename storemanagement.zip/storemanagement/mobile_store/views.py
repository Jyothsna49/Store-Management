from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import *
from .forms import *
from django.db.models import Q

# Create your views here.
def display(request):
    return render(request, 'home.html')

def display_mobiles(request):
    if request.user.is_authenticated:
        items = MobilePhone.objects.all()
        context = {
            'items': items,
            'header': 'Mobiles',
        }
        return render(request, 'display.html', context)
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')

def display_earphones(request):
    if request.user.is_authenticated:
        items = EarPhone.objects.all()
        context = {
            'items': items,
            'header': 'Earphones',
        }
        return render(request, 'display.html', context)
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')

def display_screenguards(request):
    if request.user.is_authenticated:
        items = Screenguard.objects.all()
        context = {
            'items': items,
            'header': 'Screenguards',
        }
        return render(request, 'display.html', context)
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')


def display_cases_covers(request):
    if request.user.is_authenticated:
        items = Cases_and_Cover.objects.all()
        context = {
            'items': items,
            'header': 'Cases and Covers',
        }
        return render(request, 'display.html', context)
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')


def add_mobile(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = MobilePhoneForm(request.POST)

            if form.is_valid():
                form.save()
                return redirect('display_mobiles')
        else:
            form = MobilePhoneForm()
            return render(request, 'add.html', {'form' : form})
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')

def add_earphone(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = EarPhoneForm(request.POST)

            if form.is_valid():
                form.save()
                return redirect('display_earphones')
        else:
            form = EarPhoneForm()
            return render(request, 'add.html', {'form' : form})
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')

def add_screenguard(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = ScreenguardForm(request.POST)

            if form.is_valid():
                form.save()
                return redirect('display_screenguards')
        else:
            form = ScreenguardForm()
            return render(request, 'add.html', {'form' : form})
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')

def add_cases_covers(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = Cases_and_CoverForm(request.POST)

            if form.is_valid():
                form.save()
                return redirect('display_cases_covers')
        else:
            form = Cases_and_CoverForm()
            return render(request, 'add.html', {'form' : form})
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')


'''
def add_item(request,cls):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = cls(request.POST)

            if form.is_valid():
                form.save()
                return redirect('display')
        else:
            form = cls()
            return render(request, 'add.html', {'form' : form})
    else:
        messages.info(request,"Login is essential!!!")
        return redirect('login')


def add_mobile(request):
    return add_item(request, MobilePhoneForm)


def add_earphone(request):
    return add_item(request, EarPhoneForm)


def add_screenguard(request):
    return add_item(request, ScreenguardForm)

def add_cases_covers(request):
    return add_item(request, Cases_and_CoverForm)

def edit_item(request, pk, model, cls):
    item = get_object_or_404(model, pk=pk)

    if request.method == "POST":
        form = cls(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('display')
    else:
        form = cls(instance=item)

        return render(request, 'edit.html', {'form': form})


def edit_mobile(request, pk):
    return edit_item(request, pk, MobilePhone, MobilePhoneForm)

def edit_earphone(request, pk):
    return edit_item(request, pk, EarPhone, EarPhoneForm)

def edit_screenguard(request, pk):
    return edit_item(request, pk, Screenguard, ScreenguardForm)

def edit_cases_covers(request, pk):
    return edit_item(request, pk, Cases_and_Cover, Cases_and_CoverForm)'''

def edit_mobile(request, pk):
    item = get_object_or_404(MobilePhone, pk=pk)

    if request.method == "POST":
        form = MobilePhoneForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('display_mobiles')
    else:
        form = MobilePhoneForm(instance=item)

        return render(request, 'edit.html', {'form': form})

def edit_earphone(request, pk):
    item = get_object_or_404(EarPhone, pk=pk)

    if request.method == "POST":
        form = EarPhoneForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('display_earphones')
    else:
        form = EarPhoneForm(instance=item)

        return render(request, 'edit.html', {'form': form})

def edit_screenguard(request, pk):
    item = get_object_or_404(Screenguard, pk=pk)

    if request.method == "POST":
        form = ScreenguardForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('display_screenguards')
    else:
        form = ScreenguardForm(instance=item)

        return render(request, 'edit.html', {'form': form})

def edit_cases_covers(request, pk):
    item = get_object_or_404(Cases_and_Cover, pk=pk)

    if request.method == "POST":
        form = Cases_and_CoverForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('display__cases_covers')
    else:
        form = Cases_and_CoverForm(instance=item)

        return render(request, 'edit.html', {'form': form})


def delete_mobile(request, pk):
    template = 'display.html'
    MobilePhone.objects.filter(id=pk).delete()
    items = MobilePhone.objects.all()
    context = {
        'items': items,
    }
    return render(request, template, context)


def delete_earphone(request, pk):
    template = 'display.html'
    EarPhone.objects.filter(id=pk).delete()
    items = EarPhone.objects.all()
    context = {
        'items': items,
    }
    return render(request, template, context)


def delete_screenguard(request, pk):
    template = 'display.html'
    Screenguard.objects.filter(id=pk).delete()
    items = Screenguard.objects.all()
    context = {
        'items': items,
    }
    return render(request, template, context)

def delete_cases_covers(request, pk):

    template = 'dispaly.html'
    Cases_and_Cover.objects.filter(id=pk).delete()
    items = Cases_and_Cover.objects.all()
    context = {
        'items': items,
    }
    return render(request, template, context)

def three(request):
    #if request.method=="POST":
    context={
    'res1':MobilePhone.objects.filter(in_stock__lte=3),
    'res2':EarPhone.objects.filter(in_stock__lte=3),
    'res3':Screenguard.objects.filter(in_stock__lte=3),
    'res4':Cases_and_Cover.objects.filter(in_stock__lte=3)
    }
    return render(request,"three.html",context)
    #return render(request,"three.html")

'''def search(request):
    if request.method=="POST":
        query_brand=request.POST.get('brand',None)
        if query_brand:
            results=MobilePhone.objects.filter(brand__contains=query_brand)
            return render(request,'search.html',{"results":results})
    return render(request,'search.html')'''

def search(request):
    if request.method == 'GET':
        query= request.GET.get('q')
        submitbutton="Search"

        if query is not None:
            lookups= Q(brand__icontains=query) | Q(model__icontains=query)

            res1= MobilePhone.objects.filter(lookups).distinct()
            res2= EarPhone.objects.filter(lookups).distinct()
            res3= Screenguard.objects.filter(lookups).distinct()
            res4= Cases_and_Cover.objects.filter(lookups).distinct()

            context={'res1': res1,
                    'res2': res2,
                    'res3': res3,
                    'res4': res4,
                    'submitbutton': submitbutton}

            return render(request, 'search.html', context)

        else:
            return render(request, 'search.html')

    else:
        return render(request, 'search.html')

def orders(request):
    return render(request,'order.html')

def Bill(request):
    cus_name=request.POST['name']
    cus_num=request.POST['num']
    type=request.POST['type']
    brand=request.POST['brand']
    model=request.POST['model']
    if type == 'mobile':
        res=MobilePhone.objects.filter(brand__contains=brand).first()
        FreeGift=res.FreeGift
    elif type=='earphone':
        res=EarPhone.objects.filter(brand__contains=brand).first()
        FreeGift=res.FreeGift
    elif type=='screenguard':
        res=Screenguard.objects.filter(brand__contains=brand).first()
        FreeGift='nill'
    else:
        res=Cases_and_Cover.objects.filter(brand__contains=brand).first()
        FreeGift="nill"
    price=res.price
    if res.price > 50000:
        discount_percent=15
    elif res.price > 25000:
        discount_percent=10
    elif res.price > 10000:
        discount_percent=5
    else:
        discount_percent=0
    discount_amount=price*discount_percent/100
    final_price=price-discount_amount
    res.in_stock-=1
    res.save()
    o=Order(customer_name=cus_name,customer_number=cus_num, type_of_product=type, brand=brand, model=model, price=price, FreeGift=FreeGift,discount_amount=discount_amount,discount_percent=discount_percent,final_price=final_price)
    o.save()
    items=Order.objects.all().order_by('-id')
    return render(request,"display_order.html",{"items":items})

def display_order(request):
    items=Order.objects.all().order_by('-id')
    return render(request,"display_order.html",{"items":items})

def edit_order(request, pk):
    item = get_object_or_404(Order, pk=pk)

    if request.method == "POST":
        form = OrderForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('display_order')
    else:
        form = OrderForm(instance=item)

        return render(request, 'edit.html', {'form': form})

def view_order(request, pk):
    items = Order.objects.get(id = pk)
    context = {
        'items': items,
    }
    return render(request, 'view.html', context)

def delete_order(request, pk):

    template = 'display_order.html'
    Order.objects.filter(id=pk).delete()
    items = Order.objects.all().order_by('-id')
    context = {
        'items': items,
    }
    return render(request, template, context)

    '''
    #return redirect('display')
    order=Order.objects.last()
    p=order.pk
    item = get_object_or_404(Order, pk=p)
    if request.method == "POST":
        form = OrderForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            return redirect('three')
    else:
        form = Order(instance=item)
        return render(request, 'bill.html', {'form': form})
    return redirect('display')'''


